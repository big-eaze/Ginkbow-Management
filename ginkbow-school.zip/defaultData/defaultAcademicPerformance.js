const academicPerformance =[
  {
    "admissionNumber": "SCH-1001",
    "studentName": "Alexander Lewis",
    "class": "JSS2",
    "session": "2024/2025",
    "subjects": [
      { "name": "Mathematics", "score": 78 },
      { "name": "English", "score": 85 },
      { "name": "Science", "score": 82 },
      { "name": "History", "score": 75 },
      { "name": "Geography", "score": 80 }
    ],
    "averageScore": 80,
    "grade": "B",
    "position": 5
  }
]