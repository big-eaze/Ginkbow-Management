const classPopulationData = [
  {class: "JSS1", numberOfStudents: 89},
  {class: "JSS2", numberOfStudents: 127},
  {class: "JSS3", numberOfStudents: 89},
  {class: "SS1", numberOfStudents: 132},
  {class: "SS2", numberOfStudents: 283},
  {class: "SS3", numberOfStudents: 57}
];

export default classPopulationData;