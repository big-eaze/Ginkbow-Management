const adminIds = [
  {

    "adminId": "admin12345",
    "name": "Israel Ojeleye",
    "role": "admin",
  }
]

export default adminIds;